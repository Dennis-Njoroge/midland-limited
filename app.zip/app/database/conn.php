<?php
	$host 		= "localhost";
	$username 	= "root";
	$password 	= "";
	$dbName		= "agro";
	$conn = mysqli_connect($host,$username,$password,$dbName);
	date_default_timezone_set("Africa/Nairobi");
	$base = "http://192.168.43.98/agro_irrigation/";
    $profile_url = $base."uploads/profile_pics/";
    $product_url = $base."uploads/product_images/";

	function e($val){
	global $conn;
	return mysqli_real_escape_string($conn, trim($val));
	}
?>